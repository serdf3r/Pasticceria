<div id="modal_support" class="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-body">
                <ul>
<!--                    <li>Nome: <?php echo $this->session->logged_in['FirstName']; ?></li>
                    <li>Cognome: <?php echo $this->session->logged_in['LastName']; ?></li>
                    <li>Data Creazione: <?php echo $this->session->logged_in['CreationDate']; ?></li>
                    <li>Ultimo Accesso: <?php echo $this->session->logged_in['LastLoginDate']; ?></li>-->
                </ul>
               
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Chiudi</button>
                <!--                <button type="button" class="btn btn-primary">Save changes</button>-->
            </div>
        </div>
    </div>
</div>
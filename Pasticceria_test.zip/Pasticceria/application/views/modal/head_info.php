<script>
    $(document).ready(function () {
    });
</script>
<div class="modal fade" id="modal_info" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class=" panel text-justify m-1 p-2">
                    <h2>Utenti Attivi per Test:</h2>
                    <ul class="list-group">
                        <li class="list-group-item">User: <span class="font-weight-bold" >Luana@luana.it</span> Pass:  <span class="font-weight-bold" >Luanapass</span></li>
                        <li class="list-group-item">User:  <span class="font-weight-bold" >Maria@maria.it</span> Pass:  <span class="font-weight-bold" >Mariapass</span></li>
                    </ul>
                </div>
                <div class=" panel text-justify m-1 p-2"> 
                    <h2>Tecnologie utilizzate:</h2>
                    <ul class="list-group">
                        <li class="list-group-item">CodeIgniter: <span class="font-weight-bold" >3.1.11</span></li>
                        <li class="list-group-item">Php: <span class="font-weight-bold" >5.6+</span></li>
                        <li class="list-group-item">Bootstrap: <span class="font-weight-bold" >4.2.1</span></li>
                        <li class="list-group-item">Jquery: <span class="font-weight-bold" >3.2.1</span></li>
                        <li class="list-group-item">Database: <span class="font-weight-bold" >MariaDB</span></li>
                        <li class="list-group-item">Fontawesome: <span class="font-weight-bold" >5.11.2</span></li>
                    </ul>
                </div>
                <div class=" panel text-justify m-1 p-2">
                    <h2>Link utili:</h2>
                    <ul class="list-group">
                        <li class="list-group-item">Mia Email: <span class="font-weight-bold" ><a class="font-weight-bold" href="mailto:serdf3r@hotmail.it">serdf3r@hotmail.it</a></span></li>
                        <li class="list-group-item">Versione di prova online: <span class="font-weight-bold" ><a class="font-weight-bold" href="http://www.serdf3r.com/Pasticceria/">http://www.serdf3r.com/Pasticceria/</a></span></li>
                        <li class="list-group-item">Git: <span class="font-weight-bold" >...</span></li>
                    </ul>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Chiudi</button>
            </div>
        </div>
    </div>
</div>

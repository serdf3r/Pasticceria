<?php
$management_default = '';
$management_users = '';
$management_cakes = '';
//$management_types = '';
if ($link_active == 'management_default') {
    $management_default = 'active';
}
if ($link_active == 'management_users') {
    $management_users = 'active';
}
if ($link_active == 'management_cakes') {
    $management_cakes = 'active';
}
//if ($link_active == 'management_types') {
//    $management_types = 'active';
//}
?>

<nav class = "navbar settings">
    <ul class = "list-inline list-group ">
        <li class = "list-inline-item">
            <a class="list-group-item list-group-item-action <?php echo $management_default; ?>" href = "<?php echo base_url(); ?>index.php/Management/index">Panoramica</a>
        </li>
        <li class = "list-inline-item">
            <a class="list-group-item list-group-item-action <?php echo $management_users; ?>" href = "<?php echo base_url(); ?>index.php/Management/users">Gestisci Utenti</a>
        </li>
        <li class="list-inline-item">
            <a class="list-group-item list-group-item-action <?php echo $management_cakes; ?>" href="<?php echo base_url(); ?>index.php/Management/cakes">Gestisci Torte</a>
        </li>  
<!--        <li class="list-inline-item">
            <a class="list-group-item list-group-item-action <?php echo $management_types; ?>" href="<?php echo base_url(); ?>index.php/Management/types">Gestisci Tipologie</a>
        </li>  -->

    </ul>  
</nav>
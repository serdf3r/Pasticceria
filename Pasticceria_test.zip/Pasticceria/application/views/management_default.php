<div class=""> 
    <div class="panel-group" id="accordion">    
        <div class="panel panel-primary">
            <?php if ($this->session->flashdata('esito_success')) { ?>
                <div class="p-3 mb-2 bg-success text-white">
                    <?php echo $this->session->flashdata('esito_success'); ?>
                </div>
            <?php } ?>
            <?php if ($this->session->flashdata('esito_error')) { ?>
                <div class="p-3 mb-2 bg-danger text-white">
                    <?php echo $this->session->flashdata('esito_error'); ?>
                </div>
            <?php } ?>
            <div class="modal-body">  <div class=" panel text-justify m-1 p-2">
                    <h2>Utenti:</h2>
                    <ul class="list-group">
                        <li class="list-group-item">Totale Utenti Amministratori: <span class="font-weight-bold" >TODO count</span></li>
                        <li class="list-group-item">Totale Utenti: <span class="font-weight-bold" >TODO count</span></li>
                    </ul>
                </div>
                <div class=" panel text-justify m-1 p-2"> 
                    <h2>Torte:</h2>
                    <ul class="list-group">
                        <li class="list-group-item">Torte Vendibili per Tipologia: <span class="font-weight-bold" >TODO count</span></li>
                        <li class="list-group-item">Totale Torte Vendibili: <span class="font-weight-bold" >TODO count</span></li>
                        <li class="list-group-item">Totale Torte nella Storia: <span class="font-weight-bold" >TODO count</span></li>
                    </ul>
                </div>
            </div>  
        </div>  
    </div>  
</div>  
</div>
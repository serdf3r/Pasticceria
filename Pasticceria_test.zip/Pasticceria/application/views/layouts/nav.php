<?php //print_r($_SESSION);  ?>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand logo_def" href="<?php echo base_url(); ?>index.php/Home/"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="glyph-icon collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto ">
            <li class="nav-item ">
                <a class="nav-link btn big_title " href="<?php echo base_url(); ?>"><i class="fas fa-birthday-cake"></i> Home</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link btn big_title " href="<?php echo base_url(); ?>index.php/Welcome/old_cakes"><i class="fas fa-candy-cane"></i> Tutte le Torte Vecchie</a>
            </li>
        </ul>     
        <ul class="navbar-nav pull-right">
            <li class="nav-item ">
                <a class="nav-link btn " data-toggle="modal" data-target="#modal_info" href="modal_info"><i class="fas fa-info-circle "></i> Info </a>
            </li>
            <?php if ($_SESSION["logged_in"]["Name"] != "") { ?>
                <li class="nav-item ">
                    <a class="nav-link btn" data-toggle="modal"href="<?php echo base_url(); ?>index.php/Management/"><i class="fas fa-cogs"></i> Amministra</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link btn" data-toggle="modal" data-target="#modal_admin" href="modal_admin"><i class="fa fa-user" aria-hidden="true"></i> Gestisci profilo</a>
                </li>
            <?php } else { ?>
                <li class="nav-item ">
                    <a class="nav-link btn " href="<?php echo base_url(); ?>index.php/Login/"><i class="fas fa-sign-in-alt"></i> Login </a>
                </li>
            <?php } ?>


        </ul>
    </div>
</nav>

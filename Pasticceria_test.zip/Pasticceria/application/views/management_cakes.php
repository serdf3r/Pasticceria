<div class=""> 
    <div class="panel-group" id="accordion">    
        <div class="panel panel-primary">
            <?php if ($this->session->flashdata('esito_success')) { ?>
                <div class="p-3 mb-2 bg-success text-white">
                    <?php echo $this->session->flashdata('esito_success'); ?>
                </div>
            <?php } ?>
            <?php if ($this->session->flashdata('esito_error')) { ?>
                <div class="p-3 mb-2 bg-danger text-white">
                    <?php print_r($this->session->flashdata('esito_error')); ?>
                </div>
            <?php } ?><div class="modal-body">    
                <div class="col-12">
                    <button type="button" data-toggle="modal" data-target="#add_cake"  class="btn btn-primary"><i class="fas fa-birthday-cake"></i> Aggiungi Torta</button>
                </div>
                <div class="col-12 p-3">
                    <?php
//                    print_r("<pre>");
//                    print_r($users);
//                    print_r("</pre>");
//                    exit;
                    ?>
                    <table id="tab_cakes" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Nome Torta</th>
                                <th>Data Inserimento</th>
                                <th>Chef</th>
                                <th>Prezzo originale</th>
                                <th>Prezzo attuale</th>
                                <th>Descrizione</th>
                                <th>Ingredienti</th>
                                <th>Immagine</th>
                                <th>Vendita</th>
                                <th>Disponibilità</th>
                                <th>Modifica</th>
                                <th>Elimina</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($cakes as $row) {
                                ?>
                                <tr>
                                    <td><?php echo $row->CakeId; ?></td>
                                    <td><?php echo $row->CakeName; ?></td>
                                    <td><?php echo $row->Insert_Date; ?></td>
                                    <td><?php echo $row->ChefName; ?></td>
                                    <td><?php echo $row->Price; ?></td>
                                    <td><?php echo $row->Price; ?></td>
                                    <td><?php echo $row->Description; ?></td>
                                    <td><?php echo $row->Ingredients; ?></td>
                                    <td><?php echo $row->Picture; ?></td>
                                    <td><?php
                                        if ($row->Sale == 1) {
                                            echo '<i class="fas fa-check-circle"></i>';
                                        } else {
                                            echo '';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo $row->Quantity; ?></td>
                                    <td><button type="button" data-toggle="modal" data-target="#edit_cake" data_record_id="<?php echo $row->CakeId; ?>" data_name="<?php echo $row->CakeName; ?>" class="btn btn-primary edit_event"><i class="fas fa-edit"></i></button></td>
                                    <td><button type="button"  data-toggle="modal" data-target="#delete_cake" data_record_id="<?php echo $row->CakeId; ?>" data_name="<?php echo $row->CakeName; ?>" class="btn btn-danger delete_event"><i class="fas fa-trash-alt"></i></button></td>
                                </tr>     
                            <?php } ?> 
                        </tbody>                    
                    </table> 
                </div>  
            </div>  
        </div>  
    </div>  
</div>

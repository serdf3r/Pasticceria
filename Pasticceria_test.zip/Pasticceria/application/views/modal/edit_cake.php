<div class="modal fade" id="edit_cake" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <?php echo form_open_multipart('Management/edit_cake') ?>
            <div class="modal-header modal-header-primary">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-edit"></i> Modifica Torta <span class="font-weight-bold nome_torta"></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">                   
                <div class="row">                  
                    <div class="col-6 p-2">    
                        <div class="form-group">
                            <label for="nome">Nome Torta *</label>
                            <input type="input" class="form-control nome" id="nome" name="nome"  placeholder="Nome della Torta" required="required">
                        </div>
                        <div class="form-group">
                            <label for="data">Modifica la data se diversa da oggi</label>
                            <input type="date"  class="form-control data_torta" id="data_torta" name="data" >
                        </div>
                        <div class="form-group p-2 pl-5">
                            <input class="form-check-input sale" type="checkbox" value="1" name="sale" id="sale">
                            <label for="sale">In Vendita? </label>
                        </div>    
                    </div>
                    <div class="col-6 p-2">   
                        <div class="form-group">
                            <label for="prezzo">Prezzo *</label>
                            <input type="input" class="form-control prezzo" id="prezzo" name="prezzo"  placeholder="Prezzo" required="required">
                        </div> 
                        <div class="form-group">
                            <label for="quantita">Quantità *</label>
                            <input type="input" class="form-control quantita" id="quantita" name="quantita"  placeholder="Quantita" required="required">
                        </div> 
                        <div class="form-group">
                            <label for="image">Immagine Torta</label>
                            <figure class="m-1 figure">
                                <img src="" class="figure-img img-fluid rounded image_old" alt="" style="height: 2em;">
                            </figure>
                            <input type="file" class=" form-control-file image" name="image"  id="image">
                        </div> 
                    </div>

                    <div class="col-12 p-2">  
                        <label for="descrizione">Descrizione</label>
                        <textarea class="form-control descrizione" id="descrizione" name="descrizione"  rows="2"></textarea>
                    </div>
                    <div class="col-12 p-2">  
                        <label for="ingredienti">Ingredienti</label>
                        <textarea class="form-control ingredienti" id="ingredienti" name="ingredienti" rows="4"></textarea>
                    </div> 
                    <div class="text-info m-2"><h6>* = Obbligatorio</h6></div>
                </div> 
                <div class="modal-footer">
                    <input type="hidden" name="id_cake" class="id_cake"  value=""/>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Chiudi</button>
                    <button type="submit" class="btn btn-primary">Modifica</button>
                </div>
                <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>
<?php

class MY_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function loadDefaultTemplate($data = array()) {
        $this->load->view('layouts/header.php', $data);
        $this->load->view('layouts/nav.php', $data);
        $this->load->view('modal/head_info.php', $data);
        $this->load->view('modal/head_profile.php', $data);
//        $this->load->view('modal/head_support.php', $data);
        $this->load->view('layouts/footer.php', $data);
    }

}

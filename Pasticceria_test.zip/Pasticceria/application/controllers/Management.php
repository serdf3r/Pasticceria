<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Management extends MY_Controller {
    function __Construct() {
        parent::__Construct();
        $this->load->database(); // load database
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library("session");
        $this->load->model('Management_Model'); // load model
        if (!isset($_SESSION["logged_in"]["Name"])) {
            $session_data = array(
                'Name' => "");
            $this->session->set_userdata('logged_in', $session_data);

        }
        if ($_SESSION["logged_in"]["Name"] == '') {
            redirect('login');
        }
    }

    public function index() {
        $data = array();
        $this->data['link_active'] = 'management_default';
        $this->data['page_title'] = 'Gestisci Utenti';
        $this->load->view('layouts/header.php', $this->data);
        $this->loadDefaultTemplate($this->data);
        $this->load->view('layouts/nav_management.php', $this->data);
        $this->load->view('management_default.php');
        $this->load->view('layouts/footer.php', $this->data);
    }

    public function users() {
        $data = array();
        $this->data['link_active'] = 'management_users';
        $this->data['page_title'] = 'Gestisci Utenti';
        $this->load->view('layouts/header.php', $this->data);
        $this->loadDefaultTemplate($this->data);
        $this->load->view('layouts/nav_management.php', $this->data);
        $this->data['users'] = $this->Management_Model->getAllUsers();
        $this->load->view('management_users.php', $this->data);
        $this->load->view('modal/add_user.php');
        $this->load->view('modal/edit_user.php');
        $this->load->view('layouts/footer.php', $this->data);
    }

    public function add_user() {
        if ($this->input->post('password') == $this->input->post('password_r')) {

            $this->load->library('form_validation');

            $this->form_validation->set_rules('nome_utente', 'nome_utente', 'required');
            $this->form_validation->set_rules('password', 'password', 'required');
            $this->form_validation->set_rules('username', 'username', 'required');

            if ($this->form_validation->run() == false) {

                $response = array(
                    'status' => 'error',
                    'message' => validation_errors()
                );
            } else {
                $data = array(
                    'nome_utente' => $this->input->post('nome_utente', true),
                    'password' => $this->input->post('password', true),
                    'username' => $this->input->post('username', true),
                    'admin' => $this->input->post('admin', true)
                );
                $result = $this->Management_Model->add_user($data);
                if ($result == true) {
                    $message = "L'utente " . $this->input->post('admin') . " è stato inserito correttamente";
                    $this->session->set_flashdata("esito_success", $message);
                    redirect('Management/users');
                } else {
                    $message = $result;
                    $this->session->set_flashdata("esito_error", $message);
                    redirect('Management/users');
                }
            }
        } else {
            $message = "Le password non coincidono";
            $this->session->set_flashdata("esito_error", $message);
            redirect('Management/users');
        }
    }

    public function cakes() {
        $data = array();
        $this->data['link_active'] = 'management_cakes';
        $this->data['page_title'] = 'Gestisci Torte';
        $this->load->view('layouts/header.php', $this->data);
        $this->loadDefaultTemplate($this->data);
        $this->load->view('layouts/nav_management.php', $this->data);
        $this->data['cakes'] = $this->Management_Model->getAllCakes();
        $this->load->view('management_cakes.php', $this->data);
        $this->load->view('modal/add_cake.php');
        $this->load->view('modal/edit_cake.php');
        $this->load->view('modal/delete_cake.php');
        $this->load->view('layouts/footer.php', $this->data);
    }

    public function get_cake_by_id() {
        $data = array('id' => $_POST['id']);
        $data = $this->Management_Model->getCakeById($data);
        echo json_encode($data);
    }

    public function add_cake() {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('nome', 'nome', 'required');
        $this->form_validation->set_rules('prezzo', 'prezzo', 'required');

        if ($this->form_validation->run() == false) {

            $response = array(
                'status' => 'error',
                'message' => validation_errors()
            );
        } else {
            $data_r = "";
            if ($this->input->post('data', true) == '') {
                $data_r = date("Y-m-d");
            } else {
                $data_r = $this->input->post('data', true);
            }
            $data = array(
                'Name' => $this->input->post('nome', true),
                'Insert_Date' => $data_r,
                'Price' => $this->input->post('prezzo', true),
                'Description' => $this->input->post('descrizione', true),
                'Ingredients' => $this->input->post('ingredienti', true),
                'Chef' => $_SESSION["logged_in"]["Id"]
            );
            $result = $this->Management_Model->addCake($data);
            if ($result == true) {
                if ($_FILES["image"]["name"] != '') {
                    $id_record = $this->db->insert_id();
                    $config['upload_path'] = './uploads/';
                    $config['allowed_types'] = 'gif|jpg|jpeg|png';
                    $config['max_size'] = 100;
                    $config['max_width'] = 1024;
                    $config['max_height'] = 768;
                    $config['file_name'] = $id_record . "_img_cake";

                    $this->load->library('upload', $config);

                    if (!$this->upload->do_upload('image')) {
                        $error = array('error' => $this->upload->display_errors());
                        $message = $error;
                        $this->session->set_flashdata("esito_error", $message);
                        redirect('Management/cakes');
                        $this->load->view('upload_form', $error);
                    } else {
                        $datapath = array(
                            'Id' => $id_record,
                            'Picture' => $this->upload->data('file_name')
                        );
                        $result = $this->Management_Model->updatePathImgCake($datapath);
                        if ($result != true) {
                            $message = $result;
                            $this->session->set_flashdata("esito_error", $message);
                            redirect('Management/cakes');
                        } else {
                            $message = "La torta " . $this->input->post('nome') . " è stata inserita correttamente";
                            $this->session->set_flashdata("esito_success", $message);
                            redirect('Management/cakes');
                        }
                    }
                } else {
                    $message = "La torta " . $this->input->post('nome') . " è stata inserita correttamente ma senza immagine";
                    $this->session->set_flashdata("esito_success", $message);
                    redirect('Management/cakes');
                }
            } else {
                $message = $result;
                $this->session->set_flashdata("esito_error", $message);
                redirect('Management/cakes');
            }
        }
    }

    public function edit_cake() {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('nome', 'nome', 'required');
        $this->form_validation->set_rules('prezzo', 'prezzo', 'required');
        $this->form_validation->set_rules('quantita', 'quantita', 'required');

        if ($this->form_validation->run() == false) {

            $response = array(
                'status' => 'error',
                'message' => validation_errors()
            );
        } else {
            $data = array(
                'Quantity' => $this->input->post('quantita', true),
                'Sale' => $this->input->post('sale', true),
                'Id' => $this->input->post('id_cake', true),
                'Name' => $this->input->post('nome', true),
                'Insert_Date' => $this->input->post('data', true),
                'Price' => $this->input->post('prezzo', true),
                'Description' => $this->input->post('descrizione', true),
                'Ingredients' => $this->input->post('ingredienti', true),
                'Chef' => $_SESSION["logged_in"]["Id"]
            );
            $result = $this->Management_Model->editCake($data);
            if ($result == true) {

                $id_record = $this->input->post('id_cake', true);
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'gif|jpg|jpeg|png';
                $config['max_size'] = 100;
                $config['max_width'] = 1024;
                $config['max_height'] = 768;
                $config['overwrite'] = true;

                $config['file_name'] = $id_record . "_img_cake";

                $this->load->library('upload', $config);
                if ($_FILES["image"]["name"] != '') {
                    if (!$this->upload->do_upload('image')) {
                        $error = array('error' => $this->upload->display_errors());
                        $message = $error;
                        $this->session->set_flashdata("esito_error", $message);

                        redirect('Management/cakes');
                    } else {
                        $message = "La torta " . $this->input->post('nome') . " è stata modificata correttamente";
                        $this->session->set_flashdata("esito_success", $message);
                        redirect('Management/cakes');
                    }
                } else {
                    $message = "La torta " . $this->input->post('nome') . " è stata modificata correttamente";
                    $this->session->set_flashdata("esito_success", $message);
                    redirect('Management/cakes');
                }
            } else {
                $message = $result;
                $this->session->set_flashdata("esito_error", $message);
                redirect('Management/cakes');
            }
        }
    }

    public function delete_cake() {
        $this->load->library('form_validation');
        $data = array(
            'id_cake' => $this->input->post('id_cake', true)
        );
        $result = $this->Management_Model->deleteCake($data);
        if ($result == true) {
            $message = "La torta è stata eliminata correttamente.";
            $this->session->set_flashdata("esito_success", $message);
            redirect('Management/cakes');
        } else {
            $message = $result;
            $this->session->set_flashdata("esito_error", $message);
            redirect('Management/cakes');
        }
    }

    public function types() {
        $data = array();
        $this->data['link_active'] = 'management_types';
        $this->data['page_title'] = 'Gestisci Tipologie';
        $this->load->view('layouts/header.php', $this->data);
        $this->loadDefaultTemplate($this->data);
        $this->load->view('layouts/nav_management.php', $this->data);
        $this->load->view('modal/add_type.php');
        $this->load->view('management_types.php');
        $this->load->view('layouts/footer.php', $this->data);
    }

    public function price_today($data, $price) {
        return "gatto";
    }

}

<?php

class Welcome_Model extends CI_Model {

    function __Construct() {
        parent::__Construct();
    }

    public function getAllAviableCakes() {
        $query = $this->db->query("SELECT * , Cakes.Name as CakeName ,Cakes.Id as CakeId ,Users.Name AS ChefName FROM Cakes LEFT JOIN Users ON Cakes.Chef=Users.id WHERE Sale=1");
        return $query->result();
    }

    public function getAllOldCakes() {
        $query = $this->db->query("SELECT * , Cakes.Name as CakeName ,Cakes.Id as CakeId ,Users.Name AS ChefName FROM Cakes LEFT JOIN Users ON Cakes.Chef=Users.id WHERE Sale=0 ");
        return $query->result();
    }

}
?>


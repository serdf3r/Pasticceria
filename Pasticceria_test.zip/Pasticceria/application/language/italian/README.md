CodeIgniter - Italian
======================

This folder contains the italian translation of the CodeIgniter system/language/english files.
NOTE: translation could be not perfect and have some errors in it.

All files have to be place in: system/language/italian . <br />
And the $config['language'] variable in the application/config/config.php file has to be changed in 'italian'.

-----------------------------------------------------------------------------------------------

Questa cartella contiene la traduzione italiana dei file situati in system/language/english di CodeIgniter.
NB: la traduzione potrebbe non essere perfetta e presentare quindi degli errori. 

Tutti i file vanno messi in: system/language/italian . <br />
Inoltre la variabile $config['language'] nel file application/config/config.php va impostata come 'italian'.

<div class="modal fade" id="add_cake" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <?php echo form_open_multipart('Management/add_cake') ?>
            <div class="modal-header modal-header-primary">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-plus"></i> Aggiungi Torta<span class="font-weight-bold "></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">                   
                <div class="row">
                    <div class="col-6 p-2">                            
                        <div class="form-group">
                            <label for="nome">Nome Torta *</label>
                            <input type="input" class="form-control nome" id="nome" name="nome"  placeholder="Nome della Torta" required="required">
                        </div>
                        <div class="form-group">
                            <label for="data">Inserisci la data se diversa da oggi</label>
                            <input type="date"  class="form-control data" id="data_torta" name="data" >
                        </div>
                    </div>
                    <div class="col-6 p-2">   
                        <div class="form-group">
                            <label for="prezzo">Prezzo *</label>
                            <input type="input" class="form-control prezzo" id="prezzo" name="prezzo"  placeholder="Prezzo" required="required">
                        </div> 
                        <div class="form-group">
                            <label for="image">Immagine Torta</label>
                            <input type="file" class=" form-control-file" name="image"  id="image">
                        </div> 
                    </div>

                    <div class="col-12 p-2">  
                        <label for="descrizione">Descrizione</label>
                        <textarea class="form-control" id="descrizione" name="descrizione"  rows="2"></textarea>
                    </div>
                    <div class="col-12 p-2">  
                        <label for="ingredienti">Ingredienti</label>
                        <textarea class="form-control" id="ingredienti" name="ingredienti" rows="4"></textarea>
                    </div> 
                    <div class="text-info m-2"><h6>* = Obbligatorio</h6></div>
                </div> 
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Chiudi</button>
                    <button type="submit" class="btn btn-primary">Aggiungi</button>
                </div>
                <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>
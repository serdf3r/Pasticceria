<div class="modal-body">    
    <div class="col-12">
        <button type="button" data-toggle="modal" data-target="#add_type"  class="btn btn-primary">Aggiungi Tipologia</button>
    </div>
    <div class="col-12">
    </div>  
</div>  
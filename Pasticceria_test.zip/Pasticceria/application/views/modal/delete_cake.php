<div class="modal fade" id="delete_cake" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <?php echo form_open('Management/delete_cake') ?>
            <div class="modal-header modal-header-danger">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-trash-alt"></i> Elimina Torta<span class="font-weight-bold "></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">                   
                <div class="row">
                    <div class="col-12 p-2">                            
                        <div class="form-group">
                            Vuoi veramente elminare la Torta: <span class="nome_torta"></span> ?
                        </div>                       
                    </div>
                </div> 
                <div class="modal-footer">
                    <input type="hidden" name="id_cake" class="id_cake"  value=""/>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annulla</button>
                    <button type="submit" class="btn btn-danger">Elimina</button>
                </div>
                <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>La Pasticceria</title>
    </head>
    <body>
        <div id="container">
            <h1>Benvenuto in pasticceria</h1>
            <h2>Le Torte</h2>
            <div id="body">
                <div class="container-fluid ">
                    <div class="row">
                        <?php
                        foreach ($cakes as $row) {
                            ?>
                            <div class="col-3 mt-1 ">
                                <div class="col-12 rounded border p-1 h-100">
                                    <h4 class="  m-1"><?php echo $row->CakeName; ?></h4>
                                    <figure class="m-1 figure">
                                        <img src="../../uploads/<?php echo $row->Picture; ?>" class="figure-img img-fluid rounded" alt="<?php echo $row->Description; ?>">
                                        <figcaption class="figure-caption text-right"><?php echo $row->Description; ?></figcaption>
                                    </figure>
                                    <div class="m-1">
                                        Chef: <b><?php echo $row->ChefName; ?></b>
                                    </div>                                    
                                    <div class="m-1">                                        
                                        <a class="btn btn-primary" data-toggle="collapse" href="#ing_<?php echo $row->CakeId; ?>" role="button" aria-expanded="false" aria-controls="collapseExample">
                                            Mostra ingredienti
                                        </a>
                                        <div class="collapse" id="ing_<?php echo $row->CakeId; ?>">
                                            <div class="card card-body  mt-2">
                                                <?php echo $row->Ingredients; ?>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        <?php } ?> 

                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
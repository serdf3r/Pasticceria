<?php

class Management_Model extends CI_Model {

    function __Construct() {
        parent::__Construct();
    }

    public function add_user($data) {
        $Name = $data['nome_utente'];
        $pwd = $data['password'];
        $Username = $data['username'];
        $CreationDate = "";
        $LastLoginDate = "";
        $IsAdmin = $data['admin'];
        $query = $this->db->query("INSERT INTO Users (id, Username, pwd,Name ,  IsAdmin) "
                . "VALUE('', '$Username', '$pwd', '$Name', '$IsAdmin')");
        return $query;
    }

    public function getAllUsers() {
        $query = $this->db->query("SELECT * FROM Users ");
        return $query->result();
    }

    public function addCake($data) {
        $Name = $data['Name'];
        $Insert_Date = $data['Insert_Date'];
        $Chef = $data['Chef'];
        $Price = $data['Price'];
        $Description = $data['Description'];
        $Ingredients = $data['Ingredients'];
        $Picture = "";
        $query = $this->db->query("INSERT INTO Cakes (id, Name, Insert_Date, Chef, Price, Description, Ingredients, Picture) "
                . "VALUE('', '$Name', '$Insert_Date', '$Chef', '$Price', '$Description', '$Ingredients', '$Picture')");
        return $query;
    }

    public function updatePathImgCake($data) {
        $Id = $data['Id'];
        $Picture = $data['Picture'];
        $result = $this->db->query("UPDATE Cakes SET Picture='$Picture' WHERE Id=$Id ");
        return $result;
    }

    public function editCake($data) {
        $Id = $data['Id'];
        $Name = $data['Name'];
        $Insert_Date = $data['Insert_Date'];
        $Price = $data['Price'];
        $Description = $data['Description'];
        $Ingredients = $data['Ingredients'];
        $Sale = $data['Sale'];
        $Quantity = $data['Quantity'];
        $result = $this->db->query("UPDATE Cakes SET Name='$Name',Insert_Date='$Insert_Date',Price='$Price',Description='$Description',Ingredients='$Ingredients', Sale='$Sale', Quantity='$Quantity' WHERE Id=$Id ");
        return $result;
    }

    public function deleteCake($data) {
        $id = $data['id_cake'];
        $query = $this->db->query("DELETE FROM Cakes WHERE Id=$id");
        return $query;
    }

    public function getAllCakes() {
        $query = $this->db->query("SELECT * , Cakes.Name as CakeName ,Cakes.Id as CakeId ,Users.Name AS ChefName FROM Cakes LEFT JOIN Users ON Cakes.Chef=Users.id ");
        return $query->result();
    }

    public function getCakeById($data) {
        $id = $data['id'];
        $query = $this->db->query("SELECT * FROM   Cakes WHERE id=$id");
        return $query->result();
    }

}
?>


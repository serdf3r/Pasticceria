<?php

$lang['migration_none_found']			= "Non sono state trovate migrazioni.";
$lang['migration_not_found']			= "La migrazione richiesta non &egrave; stata trovata.";
$lang['migration_multiple_version']		= "Sono presenti pi&ugrave; migrazioni con lo stesso numero di versione: %d.";
$lang['migration_class_doesnt_exist']           = "La classe di migrazione \"%s\" non &egrave; stata trovata.";
$lang['migration_missing_up_method']            = "La classe di migrazione \"%s\" non ha un meotodo 'up'.";
$lang['migration_missing_down_method']          = "La classe di migrazione \"%s\" non ha un metodo 'down'.";
$lang['migration_invalid_filename']		= "Migrazione \"%s\" ha un filename non valido.";


/* End of file migration_lang.php */
/* Location: ./system/language/italian/migration_lang.php */

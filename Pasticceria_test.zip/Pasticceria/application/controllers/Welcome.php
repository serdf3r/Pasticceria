<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {
    function __Construct() {
        parent::__Construct();
        $this->load->database(); // load database
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->model('Welcome_Model'); // load model
        if (!isset($_SESSION["logged_in"]["Name"])) {
            $session_data = array(
                'Name' => "");
            $this->session->set_userdata('logged_in', $session_data);
            redirect('login');
        }
    }

    public function index() {
        $data = array();
        $this->data['page_title'] = 'Pasticceria';
        $this->data['cakes'] = $this->Welcome_Model->getAllAviableCakes();
        $this->loadDefaultTemplate($this->data);
        $this->load->view('home.php');
    }

    public function old_cakes() {
        $data = array();
        $this->data['page_title'] = 'Pasticceria';
        $this->data['cakes'] = $this->Welcome_Model->getAllOldCakes();
        $this->loadDefaultTemplate($this->data);
        $this->load->view('old_cakes.php');
    }

    public function price_today($data, $price) {
        $start_date = $data;
        $end_date = date("Y-m-d");
        $dateDiff = $this->dateDifference($start_date, $end_date);
        $price_ret = '';
        if ($dateDiff == 0) {
            $price_ret = $price." euro";
        } else if ($dateDiff == 1) {
            $price_ret = $price / 100 * 80 ." euro";
        } else if ($dateDiff == 2) {
            $price_ret = $price / 100 * 20 ." euro";
        } else if ($dateDiff >= 1) {
            $price_ret = "Non più in vendita";
        }
        return $price_ret ;
    }

    function dateDifference($start_date, $end_date) {
        $diff = strtotime($start_date) - strtotime($end_date);
        return ceil(abs($diff / 86400));
    }

}

$(document).ready(function () {
    console.log("ready1");
    if ($.fn.DataTable.isDataTable('#tab_users')) {
        $('#tab_users').DataTable().destroy();
    }
//    $("#add_cake").on("click", function () {
//        var now = new Date();
//
//        var day = ("0" + now.getDate()).slice(-2);
//        var month = ("0" + (now.getMonth() + 1)).slice(-2);
//
//        var today = now.getFullYear() + "-" + (month) + "-" + (day);
//        $("#data_torta").val(today);
//    });
    $('#tab_users').DataTable({
        "columnDefs": [

            {
                "targets": [0],
                "width": "1%"
            },
            {
                "targets": 4,
                "width": "1%",
                "className": "text-center",
                "orderable": false,
            },
            {
                "targets": 7,
                "width": "1%",
                "orderable": false,
                "className": "text-center",
            },
            {
                "targets": 8,
                "width": "1%",
                "orderable": false,
                "className": "text-center",
            }]
    }
    );
    if ($.fn.DataTable.isDataTable('#tab_cakes')) {
        $('#tab_cakes').DataTable().destroy();
    }

    $('#tab_cakes').DataTable({
        "columnDefs": [

            {
                "targets": [0],
                "width": "1%"
            },
            {
                "targets": [2],
                "width": "1%",
                "className": "text-center"
            },
            {
                "targets": [4],
                "width": "1%",
                "className": "text-center"
            },
            {
                "targets": 5,
                "width": "1%",
                "className": "text-center"
            },
            {
                "targets": 6,
                "width": "1%",
                "className": "text-center",
                "orderable": false,
            },
            {
                "targets": 7,
                "width": "1%",
                "orderable": false,
                "className": "text-center",
            },
            {
                "targets": 8,
                "width": "1%",
                "orderable": false,
                "className": "text-center",
            },
            {
                "targets": 9,
                "width": "1%",
                "className": "text-center",
                "orderable": false,
            },
            {
                "targets": 10,
                "width": "1%",
                "className": "text-center",
                "orderable": false,
            },
            {
                "targets": 11,
                "width": "1%",
                "className": "text-center",
                "orderable": false,
            },
            {
                "targets": 12,
                "width": "1%",
                "className": "text-center",
                "orderable": false,
            }],
        "fnDrawCallback": function () {
            console.log("fnDrawCallback");
            $('.edit_event').unbind().on("click", function () {
                var data_record_id = $(this).attr('data_record_id');
                var data_name = $(this).attr('data_name');

//                console.log(data_record_id);
//                console.log(data_name);
                $(".nome_torta").text(data_name);
                $(".data_record_id").val(data_record_id);
                $(".id_cake").val(data_record_id);
                $.ajax({
                    type: "post",
                    dataType: "json",
                    url: baseURL + "index.php/Management/get_cake_by_id/",
                    data: {id: data_record_id},
                    success: function (data) {
                        console.log(data);
                        $(".nome").val(data[0].Name);
                        $(".data_torta").val(data[0].Insert_Date);
                        $(".image_old").val(data[0].Picture);
                        $(".prezzo").val(data[0].Price);
                        $(".image_old").attr("src", "../../uploads/" + data[0].Picture);
                        $(".descrizione").val(data[0].Description);
                        $(".ingredienti").val(data[0].Ingredients);
                        $(".quantita").val(data[0].Quantity);
                        if (data[0].sale == 1) {
                            $('.sale').prop('checked', true);
                        } else {
                            $('.sale').prop('checked', true);
                        }
                    },
                    error: function (request, error) {
                        console.log(arguments);
                    },
                });
//                console.log(data_record_id);
            });
            $('.delete_event').unbind().on("click", function () {
                var data_record_id = $(this).attr('data_record_id');
                var data_name = $(this).attr('data_name');
//                console.log(data_record_id);
//                console.log(data_name);
                $(".nome_torta").text(data_name);
                $(".data_record_id").val(data_record_id);
                $(".id_cake").val(data_record_id);
            });

        }
    });

    function manage_price(date, price) {
        console.log("manage_price");
        var today = new Date();
        var millisBetween = date.getTime() - today.getTime();
        var days = millisBetween / (1000 * 3600 * 24);
        return days;
    }
});

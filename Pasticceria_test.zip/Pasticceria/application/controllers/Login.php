<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __Construct() {
        parent::__Construct();
        $this->load->database(); // load database
        $this->load->model('Login_Model'); // load model 
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library("session");
        if (!isset($_SESSION["logged_in"]["Name"])) {
            $session_data = array(
                'Name' => "");
            $this->session->set_userdata('logged_in', $session_data);
        }
    }

    public function index() {
        $data = array();
        $this->data['page_title'] = 'Login';
        $this->loadDefaultTemplate($this->data);
        $this->load->view('login.php');
    }

}

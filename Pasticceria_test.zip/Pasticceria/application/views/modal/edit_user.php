<div class="modal fade" id="edit_user" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <?php echo form_open('Management/add_user') ?>
            <div class="modal-header modal-header-primary">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-plus"></i> Modifica Utente<span class="font-weight-bold name"></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">                   
                <div class="row">
                    <div class="col-6 p-2">                            
                        <div class="form-group">
                            <label for="nome_utente">Nome Utente *</label>
                            <input type="input" class="form-control nome" id="nome_utente" name="nome_utente"  placeholder="Nome" required="required">
                        </div>
                        <div class="form-group">
                            <label for="password">Password *</label>
                            <input type="password" class="form-control password" id="password" name="password"  placeholder="password" required="required">
                        </div>
                        <div class="form-group pl-5">
                            <input class="form-check-input" type="checkbox" value="1" name="admin" id="admin">
                            <label for="admin">Amministratore </label>
                        </div>
                    </div>
                    <div class="col-6 p-2">  
                        <div class="form-group">
                            <label for="username">Username *</label>
                            <input type="email" class="form-control username" id="username" name="username"  placeholder="Email"                                   required="required">
                        </div>
                        <div class="form-group">
                            <label for="password_r">Ripeti la Password *</label>
                            <input type="password" class="form-control password_r" id="password_r" name="password_r"  placeholder="password"                                   required="required">
                        </div>
                    </div>
                </div>
                <div class="text-info m-2"><h6>* = Obbligatorio</h6></div>
            </div>  
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Chiudi</button>
                <button type="submit" class="btn btn-primary disabled">Modifica</button>
            </div>
            <?php echo form_close() ?>
        </div>
    </div>
</div>
<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title><?php echo $page_title; ?></title>
        <!-- Bootstrap CSS -->
        <link href="<?php echo base_url('assets/bootstrap-4.2.1-dist/css/bootstrap.min.css'); ?>" rel="stylesheet">
        <!-- Flag Icon CSS -->
        <link href="<?php echo base_url('assets/flag-icon-css-master/css/flag-icon.min.css'); ?>" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?php echo base_url('assets/fontawesome-free-5.11.2-web/css/all.css'); ?>" rel="stylesheet">
        <!-- Datepicker CSS -->
        <link href="<?php echo base_url('assets/datepicker/css/datepicker.css'); ?>" rel="stylesheet">
        <!-- s3r CSS -->
        <link href="<?php echo base_url('assets/css/s3r_custom_bootstrap.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/s3r_general.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/s3r_login.css'); ?>" rel="stylesheet">
        <!-- Datatable -->
        <link href="<?php echo base_url('assets/datatable/datatables.css'); ?>" rel="stylesheet">
        <!-- Timepicker -->
        <link href="<?php echo base_url('assets/timepicker/timepicker.css'); ?>" rel="stylesheet">
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="<?php echo base_url('assets/jquery/jquery-3.2.1.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/jquery/jquery.validate.min.js'); ?>"></script>

        <!-- Datepicker -->
        <script src="<?php echo base_url('assets/datepicker/js/bootstrap-datepicker.js'); ?>"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="<?php echo base_url('assets/bootstrap-4.2.1-dist/js/bootstrap.js'); ?>"></script>
        <!-- Chart library -->
        <script src="<?php echo base_url('assets/chart/Chart.js'); ?>" crossorigin="anonymous"></script>
        <!-- Chart Timepicker -->
        <script src="<?php echo base_url('assets/timepicker/timepicker.js'); ?>"  crossorigin="anonymous"></script>
        <!-- s3r -->
        <script src="<?php echo base_url('assets/js/s3r_general.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/s3r_datatable.js'); ?>"></script>
        <!-- Datatable -->
        <script src="<?php echo base_url('assets/datatable/datatables.js'); ?>"></script>
        <!-- Sprite -->
        <!--<script src="<?php echo base_url('assets/glyph-iconset-master/sprite/iconwc.js'); ?>"></script>-->
        <!-- Validator -->
        <script src="<?php echo base_url('assets/bootstrap-validator-master/js/validator.js'); ?>"></script>
        <link rel="icon" href="<?php echo base_url('assets/images/logo/logo.ico'); ?>" type="image/gif">
        <script type='text/javascript'>var baseURL = "<?php echo base_url(); ?>";</script>
    </head>
</head>
<body>
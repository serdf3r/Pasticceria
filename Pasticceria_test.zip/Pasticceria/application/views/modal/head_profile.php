<script>
    $(document).ready(function () {
    });
</script>
<?php if ($_SESSION["logged_in"]["Name"] != "") { ?>
    <div class="modal fade" id="modal_admin" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-user"></i> <span class="font-weight-bold name"><?php
    if ($_SESSION["logged_in"]["Name"] != "") {
        echo $this->session->logged_in['Username'];
    }
    ?></span></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body"> 
                    <div class="row">
                        <div class="col-6 p-2">  
                            <h3>Informazioni</h3>
                            <ul class="list-group">
                                <li class="list-group-item m-1">Id: <span class="font-weight-bold" ><?php echo $this->session->logged_in['Id']; ?></span></li>
                                <li class="list-group-item m-1">Nome: <span class="font-weight-bold" ><?php echo $this->session->logged_in['Name']; ?></span></li>
                                <li class="list-group-item m-1">Amministratore: <span class="font-weight-bold" >
                                        <?php
                                        if ($_SESSION["logged_in"]["Name"] != "") {
                                            if ($this->session->logged_in['Username'] == 1) {
                                                echo 'Si';
                                            } else {
                                                echo 'No';
                                            }
                                        }
                                        ?></span></li>
                            </ul>
                        </div>
                        <div class="col-6 p-2">  
                            <?php echo form_open('') ?>
                            <h3>Cambio Password</h3>
                            <div class="form-group">
                                <label for="old_pass">Vecchia Password</label>
                                <input type="password" class="form-control old_pass" id="old_pass"  name="old_pass"  required="required">
                            </div>
                            <div class="form-group">
                                <label for="new_pass">Nuova Password</label>
                                <input type="password" class="form-control new_pass" id="new_pass"  name="new_pass"  required="required">
                            </div>
                            <div class="form-group">
                                <label for="repeat_new_pass">Ripeti Nuova Password</label>
                                <input type="password" class="form-control repeat_new_pass" id="repeat_new_pass"  name="repeat_new_pass"  required="required">
                            </div>
                            <input type="hidden" name="id_edit"  value="<?php echo $this->session->logged_in['Id']; ?>">
                            <button type="submit" class="btn btn-primary disabled">Modifica</button>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Chiudi</button>
                    <?php echo form_open('User_authentication/logout'); ?>
                    <button type="submit" class="btn btn-primary" >Logout</button>
                    <?php echo form_close(); ?>               
            </div>
        </div>
    </div>
</div>
<?php }?>
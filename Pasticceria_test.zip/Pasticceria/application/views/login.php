<div class="container_farm"> 
    <div class="panel-group" id="accordion">    
        <div class="panel panel-primary">
            <?php if ($this->session->flashdata('esito_success')) { ?>
                <div class="p-3 mb-2 bg-success text-white">
                    <?php echo $this->session->flashdata('esito_success'); ?>
                </div>
            <?php } ?>
            <?php if ($this->session->flashdata('esito_error')) { ?>
                <div class="p-3 mb-2 bg-danger text-white">
                    <?php echo $this->session->flashdata('esito_error'); ?>
                </div>
            <?php } ?>


            <div class="wrapper fadeInDown login_modal">
                <div id="formContent">
                    <div class="modal-header">
                        <h2>Login</h2>
                    </div>

                    <!-- Login Form -->
                    <?php echo form_open('User_authentication/user_login_process'); ?>
                    <input type="text" id="login" class="fadeIn second" name="username" placeholder="email"
                           required="required" data-error="Obbligatorio inserire email">
                    <div class="help-block with-errors"></div>
                    <input type="password" id="password" class="fadeIn third" name="password" placeholder="password"
                           required="required" data-error="Obbligatorio inserire password">
                    <div class="help-block with-errors"></div>
                    <input type="submit" class="fadeIn fourth" value="Entra">
                    <?php echo form_close() ?>

                    <!-- Remind Passowrd -->
                    <div id="formFooter">
                        <a class="underlineHover" href="#">Dimenticata la password?</a>
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-secondary" href="<?php echo base_url(); ?>" role="button">Chiudi</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>